// API Configuration
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000';

export const API_ENDPOINTS = {
  // Fleet
  FLEET: `${API_BASE_URL}/api/fleet`,

  // Logistics
  LOGISTICS: `${API_BASE_URL}/api/logistics`,

  // Attendance
  ATTENDANCE: `${API_BASE_URL}/api/attendance`,

  // Weather
  WEATHER: `${API_BASE_URL}/api/weather`,
};

export default API_BASE_URL;
